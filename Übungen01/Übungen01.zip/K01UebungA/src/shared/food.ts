export class Food {
  constructor(
    public title: string,
    public description: string
  ) {}
}
