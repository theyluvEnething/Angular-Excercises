export interface ExpirationInterface {
  expirationDate: Date;
  isExpired(): boolean;
}
