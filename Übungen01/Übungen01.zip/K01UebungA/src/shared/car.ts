export class Car {
  constructor(
    public licenseplate: string,
    public description: string,
    public registrationyear: number,
    public imagelink?: string
  ) { }
}
