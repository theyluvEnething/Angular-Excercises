export class Address {
  constructor(
    public streetnumber: string,
    public postcodetown: string
  ) { }
}
