export class Measurement {
  constructor(
    public code: string,
    public description: string,
    public imageUrl: string
  ) { }
}
