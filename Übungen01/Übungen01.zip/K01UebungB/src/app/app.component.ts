import { Component, CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';

@Component({
  selector: 'ub-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'K01UebungB';
}
