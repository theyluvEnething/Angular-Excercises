export class Image {
  constructor (public url: String, public title: string) {}
}
